//
//  TripBaseNetManager.h
//  BaseProject
//
//  Created by ios-user23 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "TripBaseModel.h"
@interface TripBaseNetManager : BaseNetManager
+(id)GetTripDataRromNetWithPage:(NSInteger)page CompletionHandle:(void(^)(id  responseObj,NSError *error))completionHandle;




@end
