//
//  FindDetailNetManager.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FindDetailNetManager.h"
#import "FindDetailModel.h"
@implementation FindDetailNetManager
+(id)GetDataFromNetWithID :(NSInteger)ID CompletionHandle:(void(^)(id  responseObj,NSError *error))completionHandle
{
    NSString *path = [NSString stringWithFormat:@"http://chanyouji.com/api/articles/%ld.json?page=1",ID];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([FindDetailModel objectWithKeyValues:responseObj],error);
    }];
}
@end
