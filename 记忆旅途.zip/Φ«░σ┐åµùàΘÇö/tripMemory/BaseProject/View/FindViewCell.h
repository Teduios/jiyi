#import <UIKit/UIKit.h>
#import "TRImageView.h"

@interface FindViewCell : UITableViewCell

@property (nonatomic,strong) TRImageView * imgView;

@property (nonatomic,strong) UILabel * titleLb;

@property (nonatomic,strong) UILabel * detailLb;

@end