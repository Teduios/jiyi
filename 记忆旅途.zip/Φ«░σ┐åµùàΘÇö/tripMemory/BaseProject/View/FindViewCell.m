

#import "FindViewCell.h"

@implementation FindViewCell

#pragma mark - lazyLoad
- (TRImageView *)imgView
{
    if (!_imgView) {
        _imgView = [[TRImageView alloc]init];
        //_imgView.contentMode = UIViewContentModeScaleAspectFill;
    }
    return _imgView;
}

#pragma mark - lazyLoad
- (UILabel *)titleLb
{
    if (!_titleLb) {
        _titleLb = [[UILabel alloc]init];
        _titleLb.font = [UIFont fontWithName:@"TrebuchetMS-Bold" size:22];
        //_titleLb.font = [UIFont flatFontOfSize:22];
        _titleLb.textColor  = [UIColor whiteColor];
        _titleLb.numberOfLines = 0;
    }
    return _titleLb;
}
#pragma mark - lazyLoad
- (UILabel *)detailLb
{
    if (!_detailLb) {
        _detailLb = [[UILabel alloc]init];
        _titleLb.font = [UIFont fontWithName:@"TrebuchetMS-Bold" size:18];
        //_detailLb.font = [UIFont flatFontOfSize:18];
        _detailLb.textColor  = [UIColor whiteColor];
    }
    return _detailLb;
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        [self.contentView addSubview:self.imgView];
        [self.imgView addSubview:self.titleLb];
        [self.imgView addSubview:self.detailLb];
        
        //图片width等于view.width ，中心X对齐高度为
        [self.imgView mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.edges.mas_equalTo(0);
        }];
        
        [self.titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.detailLb.mas_bottom).mas_equalTo(3);
            make.left.mas_equalTo(2);
            make.width.mas_equalTo(kWindowW * 0.9);
        }];
        
        [self.detailLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(2);
            make.left.mas_equalTo(2);
            make.width.mas_equalTo(kWindowW * 0.5);
        }];
    }
    return self;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end

