//
//  PicViewCell.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicViewCell.h"

@implementation PicViewCell

#pragma mark - lazyLoad
- (TRImageView *)imgView
{
    if (!_imgView) {
        _imgView = [[TRImageView alloc]init];
    }
    return _imgView;
}

-(instancetype)init
{
    
    if (self = [super init]) {
        [self.contentView addSubview:self.imgView];
        [self.imgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    return self;
}


@end
