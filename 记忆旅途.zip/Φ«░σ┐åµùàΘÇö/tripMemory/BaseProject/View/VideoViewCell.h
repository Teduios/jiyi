//
//  VideoViewCell.h
//  BaseProject
//
//  Created by ios-user23 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRImageAddBtnView.h"
#import "TRImageView.h"
@interface VideoViewCell : UITableViewCell
@property (nonatomic,strong) TRImageView * imgView;

@property (nonatomic,strong) UILabel * titleLb;

@property (nonatomic,strong) UILabel * durationLb;

@property (nonatomic,strong) FUIButton * btn;
@end
