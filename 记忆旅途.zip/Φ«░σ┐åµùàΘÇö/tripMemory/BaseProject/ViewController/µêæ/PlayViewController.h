//
//  PlayViewController.h
//  BaseProject
//
//  Created by ios-user23 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVKit/AVKit.h>
#import <AVFoundation/AVFoundation.h>
@interface PlayViewController : UIViewController
@property (nonatomic,strong) NSURL * playUrl;
@property (nonatomic,strong) NSURL * webUrl;
@end
