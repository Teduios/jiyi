//
//  FaXianViewController.h
//  BaseProject
//
//  Created by ios-user23 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FindViewmodel.h"
@interface FaXianViewController : UITableViewController
+ (UINavigationController *)standardTuWanNavi;

@property (nonatomic,strong) FindViewmodel * FindVM;
@end
