//
//  PicDetailViewController.h
//  BaseProject
//
//  Created by ios-user23 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PictureViewModel.h"
#import "PictureBaseModel.h"
@interface PicDetailViewController : UIViewController

@property (nonatomic,strong) NSURL * firstURL;

@property (nonatomic,strong) NSArray * urlArr;

@end
