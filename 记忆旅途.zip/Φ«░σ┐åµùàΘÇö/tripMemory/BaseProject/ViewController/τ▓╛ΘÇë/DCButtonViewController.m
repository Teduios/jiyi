//
//  DCButtonViewController.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "DCButtonViewController.h"
#import "PicViewController.h"
#import "TRImageView.h"
@interface DCButtonViewController ()

@end

@implementation DCButtonViewController

+ (UINavigationController *)standardTuWanNavi
{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        DCButtonViewController  *vc = [[DCButtonViewController alloc]init];
        navi = [[UINavigationController alloc]initWithRootViewController:vc];
    });
    return navi;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"全景";
    self.view.frame = CGRectMake(0, 0, kWindowW , kWindowH);
    TRImageView *imgView = [TRImageView new];
    [self.view addSubview:imgView];
    self.view.backgroundColor = [UIColor lightGrayColor];
    DCPathButton *dcPathButton = [[DCPathButton alloc]
                                  initDCPathButtonWithSubButtons:6
                                  totalRadius:60
                                  centerRadius:15
                                  subRadius:15
                                  centerImage:@"custom_center"
                                  centerBackground:nil
                                  subImages:^(DCPathButton *dc){
                                      [dc subButtonImage:@"custom_1" withTag:0];
                                      [dc subButtonImage:@"custom_2" withTag:1];
                                      [dc subButtonImage:@"custom_3" withTag:2];
                                      [dc subButtonImage:@"custom_4" withTag:3];
                                      [dc subButtonImage:@"custom_5" withTag:4];
                                      [dc subButtonImage:@"custom_1" withTag:5];
                                      
                                  }
                                  subImageBackground:nil
                                  inLocationX:0 locationY:0 toParentView:self.view];
    dcPathButton.delegate = self;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
}

#pragma mark - DCPathButton delegate

- (void)button_0_action{
    NSLog(@"Button Press Tag 0!!");
    PicViewController *vc = [PicViewController new];
    vc.infoType = 0;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)button_1_action{
    NSLog(@"Button Press Tag 1!!");
    PicViewController *vc = [PicViewController new];
    vc.infoType = 1;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)button_2_action{
    NSLog(@"Button Press Tag 2!!");
    PicViewController *vc = [PicViewController new];
    vc.infoType = 2;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)button_3_action{
    NSLog(@"Button Press Tag 3!!");
    PicViewController *vc = [PicViewController new];
    vc.infoType = 3;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)button_4_action{
    NSLog(@"Button Press Tag 4!!");
    PicViewController *vc = [PicViewController new];
    vc.infoType = 4;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)button_5_action{
    NSLog(@"Button Press Tag 5!!");
    PicViewController *vc = [PicViewController new];
    vc.infoType = 5;
    [self.navigationController pushViewController:vc animated:YES];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
