//
//  PictureViewController.h
//  BaseProject
//
//  Created by ios-user23 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PSCollectionView.h"
@interface PictureViewController : UIViewController
@property (nonatomic , assign)NSInteger infoType;
@end
