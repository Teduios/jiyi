//
//  TripViewController.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TripViewController.h"
#import "TripViewCell.h"
#import "TripViewModel.h"
#import "TripDetailController.h"
#import "TripCell.h"
#import "Factory.h"
@interface TripViewController ()

@property (nonatomic,strong) TripViewModel * tripVM;

@end

@implementation TripViewController


+ (UINavigationController *)standardTuWanNavi
{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        TripViewController  *vc = [[TripViewController alloc]init];
        navi = [[UINavigationController alloc]initWithRootViewController:vc];
    });
    return navi;
}

#pragma mark - lazyLoad
- (TripViewModel *)tripVM
{
    if (!_tripVM) {
        _tripVM = [[TripViewModel alloc]init];
    }
    return _tripVM;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    [Factory addMenuItemToVC:self];
    self.title = @"首页";
    /**注册cell*/
    [self.tableView registerClass:[TripCell class] forCellReuseIdentifier:@"Cell"];
    /*
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.FindVM refreshDataCompletionHandle:^(NSError *error) {
            [self.tableView reloadData];
            [self.tableView.header endRefreshing];
            
            NSLog(@"................");
        }];
    }];
    self.tableView.footer = [MJRefreshAutoFooter footerWithRefreshingBlock:^{
        [self.FindVM getMoreDataCompletionHandle:^(NSError *error) {
            [self.tableView reloadData];
            [self.tableView.footer endRefreshing];
        }];
    }];
    
    [self.tableView.header beginRefreshing];
    */
    
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.tripVM refreshDataCompletionHandle:^(NSError *error) {
            [self.tableView reloadData];
            [self.tableView.header endRefreshing];
            
            NSLog(@"..............");
        }];
    }];
    
    self.tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self.tripVM getMoreDataCompletionHandle:^(NSError *error) {
            [self.tableView reloadData];
            [self.tableView.footer endRefreshing];
        }];
    }];
    
    [self.tableView.header beginRefreshing];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.tripVM.rowNumber;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    TripCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    [cell.imgView.imageView setImageWithURL:[self.tripVM imageURLWithIndexPath:indexPath]];
    cell.titleLb.text = [self.tripVM titleWithIndexPath:indexPath];
    cell.readLb.text = [NSString stringWithFormat:@"%ld",[self.tripVM viewsWithIndexPath:indexPath ]];
    cell.commentLb.text = [NSString stringWithFormat:@"%ld",[self.tripVM replysWithIndexPath:indexPath]];
    cell.usernameLb.text = [self.tripVM userNameWithIndexPath:indexPath];
    return cell;
}

#pragma mark - Table view delegate
//只要点击了该行的Cell就会触发该方法
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //松手后，去掉高亮状态
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    TripDetailController *vc = [TripDetailController new];
    vc.detailUrl = [self.tripVM detailStrWithIndexPath:indexPath];
    [self.navigationController pushViewController:vc animated:YES];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return kWindowW*3/8.0*200/300;
}

@end
