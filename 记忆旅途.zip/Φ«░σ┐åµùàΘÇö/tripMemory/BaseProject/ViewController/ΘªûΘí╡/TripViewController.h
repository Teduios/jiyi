//
//  TripViewController.h
//  BaseProject
//
//  Created by ios-user23 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TripViewController : UITableViewController
+ (UINavigationController *)standardTuWanNavi;
@end
