//
//  TripViewModel.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TripViewModel.h"
#import "TripBaseNetManager.h"
@implementation TripViewModel


//获取更多
- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle
{
    self.page += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
//刷新
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    self.page = 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
//获取数据
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask  = [TripBaseNetManager GetTripDataRromNetWithPage:_page CompletionHandle:^(TripBaseModel* responseObj, NSError *error) {
        if (_page == 1) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:responseObj.data];
        completionHandle(error);
    }];
}


-(NSInteger)rowNumber
{
    return self.dataArr.count;
}

-(DataModel *)dataModelWithIndexPath:(NSIndexPath *)indexPath
{
    return self.dataArr[indexPath.row];
}

-(NSURL *)imageURLWithIndexPath:(NSIndexPath *)indexPath
{
    return [NSURL URLWithString:[self dataModelWithIndexPath:indexPath].photo];
}

-(NSString *)titleWithIndexPath:(NSIndexPath *)indexPath
{
    return[self dataModelWithIndexPath:indexPath].title;
}

-(NSString *)userNameWithIndexPath:(NSIndexPath *)indexPath
{
    return [self dataModelWithIndexPath:indexPath].username;
}

-(NSInteger)replysWithIndexPath:(NSIndexPath *)indexPath
{
    return [self dataModelWithIndexPath:indexPath].replys.integerValue;
}

-(NSInteger)viewsWithIndexPath:(NSIndexPath *)indexPath
{
    return [self dataModelWithIndexPath:indexPath].views ;
}

-(NSString *)detailStrWithIndexPath:(NSIndexPath*)indexPath
{
    return [self dataModelWithIndexPath:indexPath].view_url;
}

@end
