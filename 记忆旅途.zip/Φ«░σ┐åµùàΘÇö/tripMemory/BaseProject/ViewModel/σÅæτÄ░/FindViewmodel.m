//
//  FindViewmodel.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FindViewmodel.h"
#import "FindNetManager.h"
#import "FindModel.h"
@interface FindViewmodel ()
@property (nonatomic , assign) NSInteger page;

@end

@implementation FindViewmodel

//获取更多
- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle
{
    self.page += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
//刷新
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    self.page = 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
//获取数据
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    self.dataTask  = [FindNetManager GetFindDataRromNetWithPage:_page CompletionHandle:^(NSArray * responseObj, NSError *error) {
        if (_page == 1) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:responseObj];
        completionHandle(error);
        
    }];
}

-(NSInteger)rowNumber
{
    return self.dataArr.count;
}

-(FindModel *)findModelWithIndexPath:(NSIndexPath*)indexPath
{
    return self.dataArr[indexPath.row];
}

-(NSURL *) URLImageWithIndexPath:(NSIndexPath*)indexPath
{
    return [NSURL URLWithString:[self findModelWithIndexPath:indexPath].image_url];
}

-(NSString*)nameWithIndex:(NSIndexPath*)indexPath
{
    return [self findModelWithIndexPath:indexPath].name;
}

-(NSString*)titleWithIndex:(NSIndexPath*)indexPath
{
    return [self findModelWithIndexPath:indexPath].title;
}

@end
