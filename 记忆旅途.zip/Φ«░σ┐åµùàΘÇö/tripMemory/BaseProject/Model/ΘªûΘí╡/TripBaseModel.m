//
//  TripBaseModel.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TripBaseModel.h"

@implementation TripBaseModel


+ (NSDictionary *)objectClassInArray{
    return @{@"data" : [DataModel class]};
}
@end
@implementation DataModel

@end


