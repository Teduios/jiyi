//
//  FindDetailModel.h
//  BaseProject
//
//  Created by ios-user23 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class Article_SectionsModel,Description_User_Ids;
@interface FindDetailModel : BaseModel

@property (nonatomic, strong) NSArray<Article_SectionsModel *> *article_sections;

@property (nonatomic, assign) BOOL current_user_favorite;

@property (nonatomic, assign) NSInteger id;

@property (nonatomic, copy) NSString *image_url;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, assign) NSInteger destination_id;

@property (nonatomic, assign) BOOL commentable;

@property (nonatomic, assign) NSInteger updated_at;

@property (nonatomic, assign) NSInteger comments_count;

@property (nonatomic, copy) NSString *name;

@end
@interface Article_SectionsModel : NSObject

@property (nonatomic, copy) NSString *description;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *image_url;

@property (nonatomic, assign) NSInteger image_width;

@property (nonatomic, assign) NSInteger image_height;

@property (nonatomic, strong) Description_User_Ids *description_user_ids;

@end

@interface Description_User_Ids : NSObject

@end

