//
//  FindDetailModel.m
//  BaseProject
//
//  Created by ios-user23 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FindDetailModel.h"

@implementation FindDetailModel


+ (NSDictionary *)objectClassInArray{
    return @{@"article_sections" : [Article_SectionsModel class]};
}
@end
@implementation Article_SectionsModel

@end


@implementation Description_User_Ids

@end


